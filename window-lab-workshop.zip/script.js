function toggleDrawer() {
    const drawer = document.getElementById('onboardingDrawer');
    drawer.classList.toggle('open');
}

function switchRole(role) {
    alert('Switched view to: ' + role.toUpperCase() + ' mode.\nIn production, this toggles permissions and dashboard layouts.');
}

function filterDiscipline(category, element) {
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    element.classList.add('active');
}

let step = 1;
const steps = ['JOIN', 'PROFILE', 'WORK', 'VISION', 'CAPABILITY', 'REVIEW', 'APPROVED'];

function nextStep() {
    if (step < 7) {
        step++;
        document.getElementById('currentStep').innerText = step;
        document.getElementById('stepTitle').innerText = steps[step - 1];
        if (step === 7) {
            alert('Application submitted! Status: PENDING ADMIN REVIEW.');
            toggleDrawer();
            step = 1;
            document.getElementById('currentStep').innerText = 1;
            document.getElementById('stepTitle').innerText = steps[0];
        }
    }
}
