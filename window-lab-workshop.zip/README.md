# Window Lab Workshop - VS Code Project Setup

Welcome to the **Window Lab Workshop** source code package.

## 📁 Directory Structure
```
window-lab-workshop/
├── index.html     # Main HTML5 layout & components
├── style.css      # Dark studio theme CSS design
├── script.js     # Role switcher & drawer logic
└── README.md      # Setup guide
```

## 🚀 How to Run in VS Code:
1. Extract the `window-lab-workshop.zip` file.
2. Open **VS Code** -> `File` -> `Open Folder...` -> Select `window-lab-workshop`.
3. Install the **Live Server** extension in VS Code.
4. Right-click `index.html` and select **"Open with Live Server"**.
